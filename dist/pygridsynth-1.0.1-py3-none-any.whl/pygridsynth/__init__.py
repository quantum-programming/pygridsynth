from .gridsynth import *
from .__main__ import main
